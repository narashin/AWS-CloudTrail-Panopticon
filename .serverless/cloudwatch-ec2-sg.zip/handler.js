'use strict';
const AWS = require('aws-sdk');
const { IncomingWebhook } = require('@slack/webhook');

module.exports.panopticon = async (event, context, callback) => {
    const webhook = new IncomingWebhook(process.env.SLACK_URL);
    // const webhook = new IncomingWebhook('https://hooks.slack.com/services/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');
    const ec2 = new AWS.EC2();
    const groupId = event.requestParameters.groupId;
    const eventName = event.eventName;

    async function findSecurityGroup(){
        let resp = await ec2.describeSecurityGroups(
            {
                GroupIds: [
                    groupId
                ]
            }, function (err, data){
                if(err) console.log(err, err.stack);
                else return data;
            }
        ).promise();
        return resp;
    }

    function formatMessage(sg, eventName){
        let thumbnailImage = '';
        const createImage = 'https://img.icons8.com/color/48/000000/new-by-copy.png';
        const editImage = 'https://img.icons8.com/color/48/000000/edit-property.png';
        const deleteImage = 'https://img.icons8.com/color/48/000000/delete-property.png';
        switch(eventName){
            case 'CreateSecurityGroup': thumbnailImage = createImage;
            case 'DeleteSecurityGroup': thumbnailImage = deleteImage;
            case 'AuthorizeSecurityGroupEgress': thumbnailImage = editImage;
            case 'AuthorizeSecurityGroupIngress': thumbnailImage = editImage;
            case 'RevokeSecurityGroupEgress': thumbnailImage = editImage;
            case 'RevokeSecurityGroupIngress': thumbnailImage = editImage;

        };

        let slackText = {
            "blocks": [
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": `SecurityGroup 변경 사항 발생 *(${eventName})*`
                    }
                },
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": `*EventName:*\n${eventName}\n*Account Id:*\nddd\n*EventTime:* 이벤트발생시간\n*Source IP* 0.0.0.0/0 \n*User Name:* \"Family in town, going camping!\"\n*AWS Region:* ap-northeast-2\n *Security Group ID:* sg-어쩌구`
                    },
                    "accessory": {
                        "type": "image",
                        "image_url": "https://api.slack.com/img/blocks/bkb_template_images/approvalsNewDevice.png",
                        "alt_text": "status thumbnail"
                    }
                },
                {
                    "type": "divider"
                },
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": "Security Group IpPermissions"
                    },
                    "fields": [
                        {
                            "type": "plain_text",
                            "text": "*this is plain_text text*",
                            "emoji": true
                        },
                        {
                            "type": "plain_text",
                            "text": "*this is plain_text text*",
                            "emoji": true
                        }
                    ]
                    
                },
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": "Security Group IpPermissionsEgress"
                    },
                    "fields": [
                        {
                            "type": "plain_text",
                            "text": "*this is plain_text text*",
                            "emoji": true
                        },
                        {
                            "type": "plain_text",
                            "text": "*this is plain_text text*",
                            "emoji": true
                        }
                    ]
                    
                },
            ]
        }

        return slackText;
        
    }


    (async() => {
        const sg = await findSecurityGroup(); 
        const message = await formatMessage(sg, eventName);
        await webhook.send(message);

    })();

}
